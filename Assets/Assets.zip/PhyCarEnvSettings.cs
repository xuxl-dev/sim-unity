using UnityEngine;

public class PhyCarEnvSettings : MonoBehaviour {
  public bool UseRandomSpawnPos = true;
}